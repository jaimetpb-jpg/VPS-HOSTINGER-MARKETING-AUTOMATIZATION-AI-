#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; source .env; set +a; }
cd phase-2-marketing
docker compose --env-file ../.env up -d
cd ..
sleep 15
docker ps --filter "name=nexus-" --format "table {{.Names}}\t{{.Status}}"
echo "✅ FASE 2 desplegada (Evolution + Listmonk + Postiz v2.21.7)"
