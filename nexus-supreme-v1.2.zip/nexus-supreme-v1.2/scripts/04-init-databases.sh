#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.2 · 02 · Inicializar BASES DE DATOS
#
# BUG #1 FIX (Kimi): No usa /docker-entrypoint-initdb.d/ (que solo
# corre 1 vez). Este script corre SIEMPRE de forma segura.
#
# Las passwords pasan vía variables psql (\set), no sed.
# Resistente a caracteres especiales en passwords.
# Cada CREATE protegido con IF NOT EXISTS o DO $$ ... END $$.
# ═══════════════════════════════════════════════════════════════
set -euo pipefail

cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; source .env; set +a; } || { echo "✗ Falta .env"; exit 1; }

echo "→ Esperando Postgres..."
for i in {1..30}; do
  if docker exec nexus-postgres pg_isready -U "${PG_ADMIN_USER}" &>/dev/null; then
    echo "✓ Postgres listo"
    break
  fi
  sleep 2
  [ "$i" -eq 30 ] && { echo "✗ Postgres no responde después de 60s"; exit 1; }
done

echo "→ Ejecutando 00-bootstrap.sql (idempotente)..."
docker cp db-init/00-bootstrap.sql nexus-postgres:/tmp/00-bootstrap.sql

docker exec -e PGPASSWORD="${PG_ADMIN_PASS}" nexus-postgres \
  psql -U "${PG_ADMIN_USER}" -d postgres -v ON_ERROR_STOP=1 \
    -v "pg_dify_pass=${PG_DIFY_PASS}" \
    -v "pg_n8n_pass=${PG_N8N_PASS}" \
    -v "pg_litellm_pass=${PG_LITELLM_PASS}" \
    -v "pg_nexus_core_pass=${PG_NEXUS_CORE_PASS}" \
    -v "pg_nocobase_pass=${PG_NOCOBASE_PASS}" \
    -v "pg_listmonk_pass=${PG_LISTMONK_PASS}" \
    -v "pg_postiz_pass=${PG_POSTIZ_PASS}" \
    -v "pg_evolution_pass=${PG_EVOLUTION_PASS}" \
    -v "pg_plausible_pass=${PG_PLAUSIBLE_PASS}" \
    -f /tmp/00-bootstrap.sql

echo "✓ Bootstrap completo"

echo "→ Ejecutando 01-nexus-core.sql (tablas operativas)..."
docker cp db-init/01-nexus-core.sql nexus-postgres:/tmp/01-nexus-core.sql

docker exec -e PGPASSWORD="${PG_NEXUS_CORE_PASS}" nexus-postgres \
  psql -U nexus_core_app -d nexus_core -v ON_ERROR_STOP=1 \
    -f /tmp/01-nexus-core.sql

echo "✓ nexus_core tables creadas"

# Cleanup
docker exec nexus-postgres rm -f /tmp/00-bootstrap.sql /tmp/01-nexus-core.sql

# Verificación
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  DBs creadas:"
docker exec -e PGPASSWORD="${PG_ADMIN_PASS}" nexus-postgres \
  psql -U "${PG_ADMIN_USER}" -d postgres -c "\l" | grep -E "dify|n8n|litellm|nexus_core|nocobase|listmonk|postiz|evolution|plausible"
echo ""
echo "  Users creados:"
docker exec -e PGPASSWORD="${PG_ADMIN_PASS}" nexus-postgres \
  psql -U "${PG_ADMIN_USER}" -d postgres -c "\du" | grep "_app"
echo "═══════════════════════════════════════════════════════════"
echo "✅ Init de DBs completo"
echo ""
echo "ESTE SCRIPT ES IDEMPOTENTE - puedes ejecutarlo cuantas veces necesites."
echo "Útil para redeploys, upgrades, troubleshooting."
