#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.2 · 00 · Prep VPS
# BUG #7 fix: UFW abre 45876 condicionalmente para Beszel agent
# ═══════════════════════════════════════════════════════════════
set -euo pipefail

echo "═══════════════════════════════════════════════════════════"
echo "  NEXUS v1.2 · Prep VPS"
echo "═══════════════════════════════════════════════════════════"

# ─── Docker ───
if ! command -v docker &> /dev/null; then
  echo "→ Instalando Docker..."
  curl -fsSL https://get.docker.com | sh
  systemctl enable --now docker
else
  echo "✓ Docker: $(docker --version)"
fi

if ! docker compose version &> /dev/null; then
  apt-get update && apt-get install -y docker-compose-plugin
fi
echo "✓ Compose: $(docker compose version)"

# ─── Firewall ───
echo "→ Configurando UFW..."
if command -v ufw &> /dev/null; then
  ufw allow 22/tcp || true
  ufw allow 80/tcp || true
  ufw allow 443/tcp || true

  # BUG #7 FIX: Beszel agent (puerto 45876) si fase 3 está activa
  # Se permite SOLO desde el propio host (lo único que necesita Beszel)
  # Beszel server consume desde dentro de la red Docker, no desde fuera
  if [ -f /opt/nexus/phase-3-observability/docker-compose.yml ]; then
    ufw allow from 127.0.0.1 to any port 45876 proto tcp || true
    echo "  ✓ Beszel agent port 45876 abierto localhost-only"
  fi

  ufw --force enable
  echo "✓ UFW: 22, 80, 443 abiertos"
else
  echo "⚠ UFW no instalado"
fi

# ─── Swap 4 GB ───
if [ ! -f /swapfile ]; then
  echo "→ Creando swap 4 GB..."
  fallocate -l 4G /swapfile
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  echo "/swapfile none swap sw 0 0" >> /etc/fstab
fi
sysctl vm.swappiness=10 > /dev/null
echo "vm.swappiness=10" > /etc/sysctl.d/99-nexus.conf

# ─── Docker networks ───
echo "→ Redes Docker..."
for net in nexus-public nexus-backbone nexus-ai nexus-automation nexus-monitoring; do
  if ! docker network ls --format '{{.Name}}' | grep -qw "$net"; then
    if [ "$net" = "nexus-backbone" ]; then
      docker network create --internal "$net"
    else
      docker network create "$net"
    fi
    echo "  ✓ $net"
  fi
done

# ─── Validaciones ───
RAM_GB=$(awk '/MemTotal/ {printf "%.0f", $2/1024/1024}' /proc/meminfo)
if [ "$RAM_GB" -lt 16 ]; then
  echo "⚠ RAM: ${RAM_GB} GB — mínimo recomendado 16 GB"
else
  echo "✓ RAM: ${RAM_GB} GB"
fi

DISK_GB=$(df -BG /opt 2>/dev/null | awk 'NR==2 {gsub("G","",$4); print $4}' || df -BG / | awk 'NR==2 {gsub("G","",$4); print $4}')
echo "✓ Disco libre: ${DISK_GB} GB"

# ─── /tmp como NO-tmpfs para backups (BUG #10 prep) ───
# Verificar si /tmp es tmpfs (lo es por defecto en muchos VPS)
if mount | grep -q "tmpfs on /tmp"; then
  echo "⚠ /tmp es tmpfs (RAM). Backups deben evitar staging ahí (ver 08-backup-restic.sh)"
fi

echo ""
echo "✅ VPS listo"
echo "Siguiente: bash scripts/01-generate-secrets.sh"
