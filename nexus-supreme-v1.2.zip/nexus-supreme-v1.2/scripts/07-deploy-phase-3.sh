#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; source .env; set +a; }
cd phase-3-observability
docker compose --env-file ../.env up -d
cd ..
sleep 10
docker ps --filter "name=nexus-" --format "table {{.Names}}\t{{.Status}}"
echo "✅ FASE 3 desplegada"
