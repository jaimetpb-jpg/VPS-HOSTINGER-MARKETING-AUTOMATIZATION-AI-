#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.1 · 06 · Exportar credenciales generadas a /opt/nexus/secrets/
# y a n8n vía API (parcial - algunas requieren UI manual)
# ═══════════════════════════════════════════════════════════════
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; source .env; set +a; }

SECRETS_DIR="/opt/nexus/secrets"
mkdir -p "$SECRETS_DIR"
chmod 700 "$SECRETS_DIR"

EXPORTED="$SECRETS_DIR/exported.env"
> "$EXPORTED"
chmod 600 "$EXPORTED"

echo "→ Exportando credenciales obtenibles vía API..."

# ─── 1. Token Evolution API ───
echo "EVOLUTION_API_KEY=${EVOLUTION_API_KEY}" >> "$EXPORTED"

# ─── 2. LiteLLM Master Key ───
echo "LITELLM_MASTER_KEY=${LITELLM_MASTER_KEY}" >> "$EXPORTED"

# ─── 3. Listmonk admin (se conoce desde .env, no se genera) ───
echo "LISTMONK_ADMIN_USER=${LISTMONK_ADMIN_USER}" >> "$EXPORTED"
echo "LISTMONK_ADMIN_PASS=${LISTMONK_ADMIN_PASS}" >> "$EXPORTED"

# ─── 4. DIFY_API_KEY (manual desde Dify UI) ───
echo "# Generar manualmente en https://dify.${DOMAIN} → Settings → API Keys" >> "$EXPORTED"
echo "# DIFY_API_KEY=app-..." >> "$EXPORTED"

# ─── 5. NOCOBASE_TOKEN (manual desde NocoBase UI) ───
echo "# Generar manualmente en https://crm.${DOMAIN} → Settings → API" >> "$EXPORTED"
echo "# NOCOBASE_TOKEN=..." >> "$EXPORTED"

# ─── 6. POSTIZ_API_KEY (manual) ───
echo "# Generar manualmente en https://postiz.${DOMAIN} → Settings → Integrations" >> "$EXPORTED"
echo "# POSTIZ_API_KEY=..." >> "$EXPORTED"

# ─── 7. GHOST_ADMIN_TOKEN (manual cuando Ghost esté en semana 2) ───
echo "# Generar manualmente en https://blog.${DOMAIN}/ghost → Integrations" >> "$EXPORTED"
echo "# GHOST_ADMIN_TOKEN=..." >> "$EXPORTED"

echo ""
echo "✅ Credenciales auto-generadas en $EXPORTED"
echo ""
echo "⚠ Credenciales que requieren UI manual:"
echo "   - DIFY_API_KEY    (https://dify.${DOMAIN} → Settings → API Keys)"
echo "   - NOCOBASE_TOKEN  (https://crm.${DOMAIN} → Settings → API)"
echo "   - POSTIZ_API_KEY  (https://postiz.${DOMAIN} → Settings → Integration tokens)"
echo "   - GHOST_ADMIN_TOKEN  (semana 2, después de deploy de Ghost)"
echo ""
echo "Cuando las tengas, edita $EXPORTED y agrégalas."
echo "Luego en n8n crea credenciales tipo HTTP Header Auth referenciando estos valores."
