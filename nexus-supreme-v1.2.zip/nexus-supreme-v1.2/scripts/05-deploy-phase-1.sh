#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.2 · 04 · Deploy FASE 1 (después de init de DBs)
# ═══════════════════════════════════════════════════════════════
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; source .env; set +a; }

# Validar que init de DBs ya corrió
DB_COUNT=$(docker exec -e PGPASSWORD="${PG_ADMIN_PASS:-x}" nexus-postgres \
  psql -U "${PG_ADMIN_USER:-nexus_admin}" -d postgres -tAc \
  "SELECT count(*) FROM pg_database WHERE datname IN ('dify','n8n','litellm','nexus_core');" 2>/dev/null || echo "0")

if [ "$DB_COUNT" != "4" ]; then
  echo "⚠ Las DBs no están listas. Primero ejecuta: bash scripts/02-init-databases.sh"
  echo "  (Esto requiere Postgres ya corriendo en standalone primero)"
  exit 1
fi

cd phase-1-core
docker compose --env-file ../.env up -d
cd ..

echo "→ Esperando Dify migrations (puede tardar 2-3 min)..."
for i in {1..60}; do
  if docker logs nexus-dify-api 2>&1 | grep -q "Application startup complete"; then
    echo "✓ Dify listo"
    break
  fi
  sleep 5
done

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  ✅ FASE 1 desplegada"
echo "═══════════════════════════════════════════════════════════"
docker ps --filter "name=nexus-" --format "table {{.Names}}\t{{.Status}}"
free -h | grep "^Mem:"
echo ""
echo "URLs: https://traefik.${DOMAIN}, https://llm.${DOMAIN}, https://dify.${DOMAIN}, https://n8n.${DOMAIN}, https://status.${DOMAIN}"
