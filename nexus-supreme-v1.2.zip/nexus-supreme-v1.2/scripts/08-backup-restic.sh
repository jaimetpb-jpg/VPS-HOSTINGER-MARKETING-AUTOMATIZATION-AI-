#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.2 · 08 · Backup cifrado externo
#
# BUG #10 FIX (Kimi): Sin staging en /tmp (tmpfs/RAM).
# Pipes directos: pg_dumpall | restic backup --stdin
# Cero archivos temporales, cero riesgo OOM.
# ═══════════════════════════════════════════════════════════════
set -euo pipefail

cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; source .env; set +a; }

# Variables requeridas (ver .env.future):
# RESTIC_REPOSITORY, RESTIC_PASSWORD, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY

if ! command -v restic &>/dev/null; then
  echo "✗ restic no instalado. apt install restic -y"
  exit 1
fi

if [ -z "${RESTIC_PASSWORD:-}" ] || [ -z "${RESTIC_REPOSITORY:-}" ]; then
  echo "✗ Faltan vars en .env: RESTIC_PASSWORD, RESTIC_REPOSITORY"
  exit 1
fi

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
echo "═══════════════════════════════════════════════════════════"
echo "  Backup cifrado · $TIMESTAMP"
echo "═══════════════════════════════════════════════════════════"

# ─── 1. Verificar espacio disco ANTES (BUG #10 safeguard) ───
FREE_GB=$(df -BG /opt 2>/dev/null | awk 'NR==2 {gsub("G","",$4); print $4}' || df -BG / | awk 'NR==2 {gsub("G","",$4); print $4}')
if [ "$FREE_GB" -lt 5 ]; then
  echo "✗ Solo ${FREE_GB} GB libres. Necesita >=5 GB."
  exit 1
fi
echo "✓ Espacio libre: ${FREE_GB} GB"

# ─── 2. Postgres dump → restic stdin (sin staging) ───
echo "→ Backup Postgres (streaming a restic)..."
docker exec -e PGPASSWORD="${PG_ADMIN_PASS}" nexus-postgres \
  pg_dumpall -U "${PG_ADMIN_USER}" \
  | restic backup --stdin --stdin-filename "postgres_${TIMESTAMP}.sql" \
                  --tag nexus-supreme --tag postgres --tag "$TIMESTAMP"
echo "✓ Postgres backup completo"

# ─── 3. Qdrant snapshot → restic stdin ───
echo "→ Backup Qdrant..."
docker exec nexus-qdrant tar -cf - -C /qdrant storage 2>/dev/null \
  | restic backup --stdin --stdin-filename "qdrant_${TIMESTAMP}.tar" \
                  --tag nexus-supreme --tag qdrant --tag "$TIMESTAMP" \
  || echo "⚠ Qdrant backup falló (no crítico, vectores se pueden regenerar)"

# ─── 4. Volumes Docker · solo data crítica ───
echo "→ Backup volumes Docker..."
VOLUMES_CRITICAL=(
  n8n_data
  dify_storage
  evolution_instances
  listmonk_uploads
  postiz_uploads
)

for vol in "${VOLUMES_CRITICAL[@]}"; do
  VOL_PATH=$(docker volume inspect "$vol" --format '{{.Mountpoint}}' 2>/dev/null || echo "")
  if [ -n "$VOL_PATH" ] && [ -d "$VOL_PATH" ]; then
    # restic puede backupear directorios directamente, sin staging
    restic backup "$VOL_PATH" \
      --tag nexus-supreme --tag "volume-${vol}" --tag "$TIMESTAMP" \
      --exclude '*.tmp' --exclude '*.log' \
      2>/dev/null || echo "  ⚠ $vol falló"
    echo "  ✓ $vol"
  fi
done

# ─── 5. Configs (.env, compose files, workflows) ───
echo "→ Backup configs..."
restic backup .env .env.future configs/ workflows/ db-init/ \
       phase-1-core/*.yml phase-1-core/*.yaml \
       phase-2-marketing/*.yml \
       phase-3-observability/*.yml \
  --tag nexus-supreme --tag configs --tag "$TIMESTAMP" \
  2>/dev/null || echo "⚠ Backup de configs falló parcialmente"

# ─── 6. Rotación ───
echo "→ Rotación: keep 7d / 4w / 6m..."
restic forget \
  --keep-daily 7 \
  --keep-weekly 4 \
  --keep-monthly 6 \
  --prune \
  --tag nexus-supreme

# ─── 7. Verificación aleatoria (1 de cada 10 runs) ───
if [ "$((RANDOM % 10))" -eq 0 ]; then
  echo "→ Verificando integridad (sample 5%)..."
  restic check --read-data-subset=5% || echo "⚠ Check found issues"
fi

echo ""
echo "✅ Backup completo: $TIMESTAMP"
echo "   Listar: restic snapshots --tag nexus-supreme"
echo "   Restaurar: restic restore <id> --target /opt/nexus/restore"
echo ""
echo "RAM usada durante backup: $(free -h | awk '/^Mem:/ {print $3}')"
