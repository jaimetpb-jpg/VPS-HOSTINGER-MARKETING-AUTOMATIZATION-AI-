#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# v1.2 · 03 · Levantar SOLO Postgres antes de init de DBs
# Esto resuelve el chicken-and-egg de v1.1
# ═══════════════════════════════════════════════════════════════
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; source .env; set +a; }

echo "→ Levantando solo Postgres (init de DBs corre después)..."
cd phase-1-core
docker compose --env-file ../.env up -d postgres
cd ..

echo "→ Esperando que Postgres acepte conexiones..."
for i in {1..30}; do
  if docker exec nexus-postgres pg_isready -U "${PG_ADMIN_USER}" &>/dev/null; then
    echo "✓ Postgres listo"
    break
  fi
  sleep 2
done

echo ""
echo "✅ Postgres standalone corriendo."
echo "SIGUIENTE: bash scripts/02-init-databases.sh"
echo "DESPUÉS:    bash scripts/04-deploy-phase-1.sh (sube el resto)"
