#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.2 · 01 · Generar secretos
#
# Mejoras vs v1.1:
# - BUG #8 fix: .env solo tiene vars usadas en fases 1-3
#               .env.future tiene vars de semana 2-3 (Authentik, Ghost, etc)
# - Opportunity I (Kimi): genera htpasswd automáticamente en traefik-basic-auth.yml
# ═══════════════════════════════════════════════════════════════
set -euo pipefail

cd "$(dirname "$0")/.."

[ -f .env ] && {
  echo "⚠ Ya existe .env"
  read -p "¿Sobreescribir? (BORRAR): " confirm
  [ "$confirm" != "BORRAR" ] && { echo "Cancelado."; exit 1; }
  mv .env ".env.bak.$(date +%Y%m%d_%H%M%S)"
}

gen() {
  openssl rand -base64 64 | tr -d '/+=\n' | head -c "${1:-32}"
}

read -p "Dominio (ej. ainexus.mx): " DOMAIN_INPUT
read -p "Email Let's Encrypt (ej. james@ainexus.com.mx): " ACME_EMAIL_INPUT
read -p "Usuario para basic auth Traefik (ej. james): " AUTH_USER
read -sp "Password para basic auth: " AUTH_PASS
echo ""
read -p "Tu WhatsApp para alertas (formato 521XXXXXXXXXX): " OPERATOR_WA

echo "→ Generando .env (fases 1-3 activas)..."

cat > .env <<EOF
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.2 · .env (FASES ACTIVAS 1-3)
# Generado: $(date)
# NO COMMIT
# ═══════════════════════════════════════════════════════════════

DOMAIN=${DOMAIN_INPUT}
ACME_EMAIL=${ACME_EMAIL_INPUT}
TZ=America/Mexico_City
OPERATOR_WHATSAPP=${OPERATOR_WA}

# ─── POSTGRES (con users por app) ───
PG_ADMIN_USER=nexus_admin
PG_ADMIN_PASS=$(gen 32)
PG_DIFY_PASS=$(gen 32)
PG_N8N_PASS=$(gen 32)
PG_LITELLM_PASS=$(gen 32)
PG_NEXUS_CORE_PASS=$(gen 32)
PG_NOCOBASE_PASS=$(gen 32)
PG_LISTMONK_PASS=$(gen 32)
PG_POSTIZ_PASS=$(gen 32)
PG_EVOLUTION_PASS=$(gen 32)
PG_PLAUSIBLE_PASS=$(gen 32)

# ─── REDIS ───
REDIS_PASS=$(gen 32)

# ─── QDRANT ───
QDRANT_KEY=$(gen 32)

# ─── DIFY ───
DIFY_SECRET_KEY=$(gen 42)

# ─── LITELLM ───
LITELLM_MASTER_KEY=sk-nexus-$(gen 32)

# ─── N8N ───
N8N_ENCRYPTION_KEY=$(gen 32)
N8N_USER_MGMT_JWT_SECRET=$(gen 32)

# ─── EVOLUTION ───
EVOLUTION_API_KEY=$(gen 32)

# ─── LISTMONK ───
LISTMONK_ADMIN_USER=admin
LISTMONK_ADMIN_PASS=$(gen 24)

# ─── POSTIZ ───
POSTIZ_JWT_SECRET=$(gen 32)

# ─── PLAUSIBLE ───
PLAUSIBLE_SECRET_KEY=$(gen 64)
PLAUSIBLE_TOTP_KEY=$(gen 32)

# ─── BESZEL ───
BESZEL_AGENT_KEY=$(gen 32)

# ═══════════════════════════════════════════════════════════════
# API KEYS — COMPLETAR A MANO
# ═══════════════════════════════════════════════════════════════
ANTHROPIC_API_KEY=sk-ant-CAMBIAME
OPENAI_API_KEY=sk-CAMBIAME
DEEPSEEK_API_KEY=sk-CAMBIAME
GEMINI_API_KEY=CAMBIAME

# SMTP (Resend recomendado)
SMTP_HOST=smtp.resend.com
SMTP_PORT=587
SMTP_USER=resend
SMTP_PASS=re_CAMBIAME
SMTP_FROM=noreply@${DOMAIN_INPUT}
EOF
chmod 600 .env

# ─── .env.future (semana 2+) ───
cat > .env.future <<EOF
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.2 · .env.future (SEMANA 2+, NO CARGAR AÚN)
# Generar cuando se despliegue cada servicio
# ═══════════════════════════════════════════════════════════════

# AUTHENTIK (semana 2 - reemplaza basic auth)
# AUTHENTIK_SECRET_KEY=$(gen 64)

# INFISICAL
# INFISICAL_ENCRYPTION_KEY=$(gen 32)
# INFISICAL_AUTH_SECRET=$(gen 32)

# GHOST (CMS, semana 2)
# GHOST_DB_PASS=$(gen 32)

# GRAFANA (semana 2 con Prometheus completo)
# GRAFANA_ADMIN_PASS=$(gen 24)

# DIFY SANDBOX (semana 2, con ENABLE_NETWORK:false)
# DIFY_SANDBOX_KEY=$(gen 32)

# CRAWL4AI (semana 2)
# CRAWL4AI_TOKEN=$(gen 32)

# SKYVERN (semana 3)
# SKYVERN_API_KEY=$(gen 32)

# NOCOBASE (semana 3 si se reactiva)
# NOCOBASE_APP_KEY=$(gen 32)

# RESTIC BACKUP
# RESTIC_REPOSITORY=s3:s3.us-ashburn-1.oraclecloud.com/nexus-backups
# RESTIC_PASSWORD=$(gen 32)
# AWS_ACCESS_KEY_ID=
# AWS_SECRET_ACCESS_KEY=
EOF
chmod 600 .env.future

# ─── Generar htpasswd automáticamente (Opportunity I) ───
echo "→ Generando htpasswd para Traefik basic auth..."
if ! command -v htpasswd &> /dev/null; then
  echo "  Instalando apache2-utils..."
  apt-get install -y apache2-utils 2>/dev/null || apk add apache2-utils 2>/dev/null
fi

HTPASSWD_HASH=$(htpasswd -nbB "$AUTH_USER" "$AUTH_PASS")
# Escapar $ para Traefik
HTPASSWD_ESCAPED=$(echo "$HTPASSWD_HASH" | sed 's/\$/\$\$/g')

mkdir -p configs
cat > configs/traefik-basic-auth.yml <<EOF
# ═══════════════════════════════════════════════════════════════
# Traefik · Basic Auth · Generado automáticamente
# Usuario: ${AUTH_USER}
# ═══════════════════════════════════════════════════════════════

http:
  middlewares:
    basic-auth:
      basicAuth:
        users:
          - "${HTPASSWD_ESCAPED}"
        realm: "NEXUS Supreme"

    secure-headers:
      headers:
        sslRedirect: true
        browserXssFilter: true
        contentTypeNosniff: true
        forceSTSHeader: true
        stsIncludeSubdomains: true
        stsPreload: true
        stsSeconds: 31536000

    rate-limit:
      rateLimit:
        average: 100
        burst: 200

    compress:
      compress: {}
EOF
chmod 600 configs/traefik-basic-auth.yml

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  ✅ Secretos generados"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "  .env             - vars activas fases 1-3 (permisos 600)"
echo "  .env.future      - vars semana 2+ (NO cargadas)"
echo "  configs/traefik-basic-auth.yml  - hash htpasswd ya inyectado"
echo ""
echo "⚠ FALTA COMPLETAR A MANO en .env:"
echo "   - ANTHROPIC_API_KEY"
echo "   - OPENAI_API_KEY"
echo "   - DEEPSEEK_API_KEY"
echo "   - GEMINI_API_KEY"
echo "   - SMTP_PASS"
echo ""
echo "Siguiente: bash scripts/02-init-databases.sh"
