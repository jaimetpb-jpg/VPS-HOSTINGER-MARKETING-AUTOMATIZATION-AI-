#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# NEXUS v1.1 · 03 · Validar secretos ANTES de deploy
# Prueba que las API keys respondan, SMTP autentique, etc.
# Detecta errores antes de tener 13 containers en crash loop.
# ═══════════════════════════════════════════════════════════════
set -uo pipefail

cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; source .env; set +a; } || { echo "✗ Falta .env"; exit 1; }

PASS=0
FAIL=0

ok() { echo "  ✅ $1"; PASS=$((PASS+1)); }
fail() { echo "  ❌ $1"; FAIL=$((FAIL+1)); }

echo "═══════════════════════════════════════════════════════════"
echo "  NEXUS v1.1 · Validación de secretos"
echo "═══════════════════════════════════════════════════════════"

# ─── 1. Placeholders ───
echo ""
echo "→ Buscando placeholders sin reemplazar..."
PLACEHOLDERS=$(grep -E "CAMBIAME|REEMPLAZAR|<GENERAR_" .env || true)
if [ -z "$PLACEHOLDERS" ]; then
  ok "Sin placeholders"
else
  fail "Hay placeholders sin reemplazar:"
  echo "$PLACEHOLDERS"
fi

# ─── 2. Anthropic API ───
echo ""
echo "→ Anthropic API..."
ANTHROPIC_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
  https://api.anthropic.com/v1/messages \
  -H "x-api-key: ${ANTHROPIC_API_KEY:-}" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{"model":"claude-haiku-4-5","max_tokens":1,"messages":[{"role":"user","content":"hi"}]}' || echo "000")

case "$ANTHROPIC_CODE" in
  200) ok "Anthropic API responde (200 OK)" ;;
  401) fail "Anthropic API key inválida (401)" ;;
  *)   fail "Anthropic API: HTTP $ANTHROPIC_CODE" ;;
esac

# ─── 3. OpenAI API ───
echo ""
echo "→ OpenAI API..."
OPENAI_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
  https://api.openai.com/v1/models \
  -H "Authorization: Bearer ${OPENAI_API_KEY:-}" || echo "000")

case "$OPENAI_CODE" in
  200) ok "OpenAI API responde" ;;
  401) fail "OpenAI API key inválida" ;;
  *)   fail "OpenAI API: HTTP $OPENAI_CODE" ;;
esac

# ─── 4. DeepSeek API ───
echo ""
echo "→ DeepSeek API..."
DS_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
  https://api.deepseek.com/v1/models \
  -H "Authorization: Bearer ${DEEPSEEK_API_KEY:-}" || echo "000")

case "$DS_CODE" in
  200) ok "DeepSeek API responde" ;;
  401) fail "DeepSeek API key inválida" ;;
  *)   fail "DeepSeek API: HTTP $DS_CODE" ;;
esac

# ─── 5. Gemini API ───
echo ""
echo "→ Gemini API..."
GEM_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
  "https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY:-}" || echo "000")

case "$GEM_CODE" in
  200) ok "Gemini API responde" ;;
  400|401|403) fail "Gemini API key inválida ($GEM_CODE)" ;;
  *)   fail "Gemini API: HTTP $GEM_CODE" ;;
esac

# ─── 6. SMTP ───
echo ""
echo "→ SMTP autenticación..."
if command -v swaks &>/dev/null; then
  if swaks --to "${SMTP_FROM}" --from "${SMTP_FROM}" \
       --server "${SMTP_HOST}:${SMTP_PORT}" \
       --auth-user "${SMTP_USER}" --auth-password "${SMTP_PASS}" \
       --tls --data 'Subject: Test\n\nNEXUS validation' \
       --timeout 10 &>/dev/null; then
    ok "SMTP autentica y envía"
  else
    fail "SMTP no autentica o no envía"
  fi
else
  echo "  ⚠ swaks no instalado, saltando test SMTP (apt install swaks)"
fi

# ─── 7. DNS wildcard ───
echo ""
echo "→ DNS wildcard..."
TEST_HOST="test-$RANDOM.${DOMAIN}"
TEST_IP=$(dig +short "$TEST_HOST" @1.1.1.1 | head -1 || echo "")
if [ -n "$TEST_IP" ]; then
  ok "Wildcard *.${DOMAIN} → $TEST_IP"
else
  fail "Wildcard *.${DOMAIN} NO resuelve. Configurar A record *.${DOMAIN}"
fi

# ─── 8. Longitud de secretos ───
echo ""
echo "→ Longitud de secretos críticos..."
for var in LITELLM_MASTER_KEY DIFY_SECRET_KEY N8N_ENCRYPTION_KEY PG_ADMIN_PASS; do
  val="${!var:-}"
  if [ ${#val} -lt 24 ]; then
    fail "$var demasiado corto (${#val} chars, mínimo 24)"
  else
    ok "$var longitud OK (${#val} chars)"
  fi
done

# ─── Resumen ───
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  RESULTADO: $PASS pasaron, $FAIL fallaron"
echo "═══════════════════════════════════════════════════════════"

if [ "$FAIL" -gt 0 ]; then
  echo ""
  echo "❌ NO DEPLOYAR HASTA RESOLVER LOS FALLOS"
  echo ""
  exit 1
else
  echo ""
  echo "✅ Listo para deployar fase 1"
  echo ""
  exit 0
fi
