# 👥 HITL · Guía Operativa de Human-in-the-Loop

> Cómo funciona la aprobación humana en NEXUS SUPREME.

---

## FILOSOFÍA

**Una agencia de marketing que cobra por publicar NO publica sin aprobación humana.**

Esto no es opcional. Es el contrato implícito con el cliente.

NEXUS automatiza el **80%** del trabajo (investigación, redacción, formateo, distribución).
El humano aporta el **20% crítico**: aprobación, criterio, tono, "feel" de marca.

---

## CICLO DE VIDA DE UN AI TASK

```
1. TRIGGER
   ↓ (webhook, cron, mensaje WA, formulario)
2. SANITIZER
   ↓ (limpia input, valida)
3. PG INSERT ai_task (status=running)
   ↓
4. DIFY WORKFLOW
   ↓ (LLM genera output)
5. PG UPDATE ai_task (status=awaiting_approval)
   ↓
6. NOTIFY OPERATOR
   ├─ WhatsApp con link de aprobación
   ├─ Mattermost canal #aprobaciones (opcional)
   └─ Dashy widget se actualiza
   ↓
7. N8N WAIT NODE  ←─── el flujo se pausa aquí ───
   ↓
8. HUMANO HACE CLICK en Dashy:
   ├─ ✅ APROBAR → flujo continúa → publica
   └─ ❌ RECHAZAR + comentario → guarda en tutor_corrections + Qdrant
   ↓
9. WEBHOOK RESUME
   ↓
10. PUBLICACIÓN (Ghost + Postiz + Listmonk + WA paralelo)
    ↓
11. PG UPDATE ai_task (status=published, published_at=NOW)
```

---

## DÓNDE SE APRUEBAN LAS COSAS

### Opción A: Dashy (panel web)
- URL: `https://panel.ainexus.mx`
- Sección "🔥 Aprobaciones Pendientes"
- Widget iframe muestra el output del LLM
- Botones: **Aprobar** | **Rechazar** | **Editar y aprobar**

### Opción B: WhatsApp (móvil)
- Operador recibe mensaje del bot:
  ```
  🤖 Nuevo contenido para revisar
  Cliente: acme-corp
  Tema: 5 errores de marketing automatizado
  Revisar y aprobar:
  https://panel.ainexus.mx/approve?task=abc-123
  ```
- Click en link abre Dashy ya filtrado a ese task

### Opción C: Mattermost (equipo)
- Canal `#aprobaciones-<tenant>`
- Bot postea card con preview + botones inline

---

## TIPOS DE APROBACIÓN POR WORKFLOW

| Workflow | Qué se aprueba | Quién aprueba |
|---|---|---|
| `content-factory` | Artículo + posts + email | Operador del tenant |
| `lead-qualifier` (HOT only) | Respuesta sugerida al lead | Comercial / James |
| `wa-concierge` (escalated only) | Cuando bot dice `[ESCALATE]` | Operador 24/7 |
| `weekly-intel` | Auto-publica (es solo digest interno) | Sin aprobación |

---

## MODO TUTOR · Cómo el sistema aprende

Cuando un humano **rechaza con comentario**:

```sql
INSERT INTO tutor_corrections (
  tenant_id, workflow_name,
  original_output, corrected_output, correction_reason
) VALUES (...);
```

Y se embeddea en Qdrant en la colección `tenant_<slug>_tutor`.

Próxima vez que el mismo workflow corra para el mismo tenant:
- Dify hace un Knowledge Retrieval sobre `tenant_<slug>_tutor`
- Inyecta las últimas 3 correcciones en el system prompt como "feedback previo del operador"
- El LLM ajusta su output considerando ese feedback

**No requiere fine-tuning.** Es RAG sobre las correcciones humanas.

---

## SLA DE APROBACIÓN

| Prioridad | Tiempo máximo | Si se vence |
|---|---|---|
| HOT lead | 30 min | Alerta a James (escalación) |
| Content (blog/social) | 4 horas | Alerta a operador (no bloquea) |
| WA escalado | 15 min | Auto-responde "asesor en breve" |
| Newsletter mass | 24 horas | Pausa hasta aprobar |

Configurar timeout en cada `Wait` node de n8n.

---

## ROLES Y PERMISOS (en Authentik)

| Grupo | Puede aprobar | Puede ver |
|---|---|---|
| `tenant-<slug>-viewer` | Nada | Solo sus propios tasks |
| `tenant-<slug>-operator` | Content, leads de su tenant | Sus tasks + métricas |
| `operators` | Tasks de cualquier tenant (rol agencia) | Todo |
| `admins` | Sí + config global | Todo + secrets |

---

## QUÉ NO PASA POR HITL

- Recolección de leads (entra a NocoBase directo)
- Logging de interacciones
- Reportes semanales internos (digest)
- Métricas de Matomo
- Backups
- Métricas LiteLLM

**Filosofía:** solo pasa por HITL lo que **toca al cliente final**.

---

## TROUBLESHOOTING HITL

### "El operador no recibe WhatsApp"
1. Verificar instancia Evolution: `curl https://wa.ainexus.mx/instance/connectionState/ainexus-main`
2. Si dice `disconnected`: reescanear QR en `https://wa.ainexus.mx`
3. Validar `OPERATOR_WHATSAPP` en `.env`

### "Aprobé pero el flujo no continúa"
1. Validar webhook URL en n8n: debe terminar en `/webhook-waiting/<id>`
2. Test manual:
   ```bash
   curl -X POST https://n8n.ainexus.mx/webhook-waiting/<task_id> \
     -H "Content-Type: application/json" \
     -d '{"approved": true, "approver": "james"}'
   ```
3. Si no responde: revisar `docker logs nexus-n8n` por errores de DB

### "Dashy no muestra los pendientes"
1. El widget consume un endpoint custom de n8n. Crear este workflow:
   - Trigger: webhook GET `/hitl-queue`
   - PG query: `SELECT * FROM ai_task WHERE status = 'awaiting_approval' ORDER BY created_at DESC LIMIT 20`
   - Return HTML formateado
2. URL del widget en `configs/dashy-conf.yml` debe apuntar a ese webhook

---

*HITL no es un feature. Es una garantía contractual con tu cliente.*
