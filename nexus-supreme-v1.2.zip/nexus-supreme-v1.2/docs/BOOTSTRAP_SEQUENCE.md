# 🔧 BOOTSTRAP SEQUENCE · NEXUS v1.1

> El paso a paso que faltaba en v1.0. **Sin esto, los workflows n8n no funcionan porque las credenciales no existen.**

---

## DÍA 1 · Después de `02-deploy-phase-1.sh`

### Paso 1.1 · Dify (20 min)
1. Abrir `https://dify.ainexus.mx`
2. Crear cuenta admin con tu email
3. Settings → Model Providers → **OpenAI-API-compatible**
   - Endpoint URL: `http://litellm:4000/v1`
   - API key: el valor de `LITELLM_MASTER_KEY` en `.env`
   - Configurar cada modelo: `cheap-spanish`, `creative`, `strategy`, `long-research`, `agent-*`
4. Settings → API Keys → crear nueva API key para n8n → **copiar** y guardar como `DIFY_API_KEY`

### Paso 1.2 · LiteLLM UI (5 min)
1. Abrir `https://llm.ainexus.mx`
2. Login: `admin` / valor de `LITELLM_MASTER_KEY`
3. Verificar que los 12 modelos aparecen en "Models"
4. Test playground: probar `cheap-spanish` con "Hola, di tu nombre"

### Paso 1.3 · n8n (15 min)
1. Abrir `https://n8n.ainexus.mx`
2. Crear cuenta admin
3. Settings → Credentials → New "Postgres":
   - Host: `postgres`
   - Database: `nexus_core`
   - User: `nexus_core_app`
   - Password: valor de `PG_NEXUS_CORE_PASS`
   - **Test connection** debe ser OK
4. Settings → Credentials → New "HTTP Header Auth":
   - Name: "Dify API"
   - Header Name: `Authorization`
   - Header Value: `Bearer <DIFY_API_KEY del paso 1.1>`
5. Settings → Credentials → New "Generic Credential":
   - Name: "LiteLLM"
   - Tipo: HTTP Bearer Auth
   - Token: `LITELLM_MASTER_KEY`

### Paso 1.4 · Validación end-to-end fase 1 (5 min)
```bash
# Test: LiteLLM → DeepSeek
curl -X POST https://llm.ainexus.mx/v1/chat/completions \
  -H "Authorization: Bearer $LITELLM_MASTER_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "cheap-spanish",
    "messages": [{"role": "user", "content": "Di hola en español, una palabra"}]
  }'
# Debe retornar {"choices":[...]}

# Test: Dify desde n8n
# En n8n, crear workflow "Test Dify" con un nodo HTTP Request:
# - URL: http://dify-api:5001/v1/workflows (con tu credencial)
# - Debe listar workflows o devolver array vacío
```

---

## DÍA 2 · Después de `04-deploy-phase-2.sh`

### Paso 2.1 · Evolution API · WhatsApp (30 min)
1. Abrir `https://wa.ainexus.mx/manager`
2. Header: `apikey: <EVOLUTION_API_KEY>`
3. Crear instancia:
   ```bash
   curl -X POST https://wa.ainexus.mx/instance/create \
     -H "apikey: $EVOLUTION_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"instanceName":"ainexus-main","qrcode":true,"integration":"WHATSAPP-BAILEYS"}'
   ```
4. Abrir manager UI → escanear QR con WhatsApp Business de AI Nexus
5. Estado debe pasar a `open`

### Paso 2.2 · NocoBase · CRM (30 min)
1. Abrir `https://crm.ainexus.mx`
2. Crear admin
3. Crear Collection **Leads**:
   - `name` (string), `email` (email), `phone` (string)
   - `company` (string), `source` (string)
   - `score` (integer 0-100), `tier` (single select: HOT/WARM/COLD)
   - `intent` (text), `tenant_slug` (string)
4. Crear Collection **Deals**:
   - `title`, `stage` (single select: lead/qualified/proposal/won/lost)
   - `amount` (decimal), `owner` (string), `tenant_slug`
5. Crear Collection **Content_Calendar**:
   - `title`, `channel` (single select), `scheduled_at` (datetime)
   - `status` (single select), `tenant_slug`
6. Settings → API → generar token → guardar como `NOCOBASE_TOKEN`

### Paso 2.3 · Listmonk (20 min)
1. Abrir `https://email.ainexus.mx`
2. Login con `LISTMONK_ADMIN_USER` / `LISTMONK_ADMIN_PASS`
3. Settings → SMTP → completar con datos de Resend (o tu proveedor)
4. Send test → debe llegar
5. Lists → crear 3:
   - `Master subscribers` (id=1)
   - `Warm nurture` (id=2)
   - `Cold drip` (id=3)
6. Settings → API → habilitar y guardar credenciales

### Paso 2.4 · Postiz (20 min)
1. Abrir `https://postiz.ainexus.mx`
2. Crear admin
3. Conectar cuentas sociales de AI Nexus (FB, IG, LinkedIn)
4. Settings → Integration tokens → generar → guardar como `POSTIZ_API_KEY`

### Paso 2.5 · Exportar credenciales a n8n
```bash
bash scripts/06-export-credentials.sh
```

Este script lee los tokens generados, los inyecta en `/opt/nexus/secrets/exported.env` y crea credenciales n8n vía API.

---

## DÍA 3 · Después de `05-deploy-phase-3.sh`

### Paso 3.1 · Plausible (10 min)
1. `https://analytics.ainexus.mx`
2. Crear cuenta admin (es invite-only por defecto)
3. Crear site `ainexus.mx` → obtener tracker script
4. Pegar en Ghost / WordPress / sitio público cuando los tengas

### Paso 3.2 · Importar 3 workflows n8n
1. En n8n: Workflows → Import → seleccionar `workflows/n8n-content-factory-v1.1.json`
2. Repetir con `n8n-lead-qualifier-v1.1.json` y `n8n-whatsapp-concierge-v1.1.json`
3. Para cada workflow:
   - Verificar que **todas las credenciales** estén mapeadas (verde, no rojo)
   - Activar el workflow (toggle arriba-derecha)
4. Test del Content Factory:
   ```bash
   curl -X POST https://n8n.ainexus.mx/webhook/content-factory \
     -H "Content-Type: application/json" \
     -d '{
       "tenant_slug": "ainexus",
       "topic": "Test desde bootstrap",
       "audience": "founders SMB",
       "channels": ["blog"],
       "language": "es"
     }'
   ```
5. Debe llegar mensaje WhatsApp al operador con link de aprobación

### Paso 3.3 · Backup cron
```bash
(crontab -l 2>/dev/null; echo "0 3 * * * /opt/nexus/scripts/08-backup-restic.sh") | crontab -
```

### Paso 3.4 · Validación final
```bash
bash scripts/03-validate-secrets.sh
docker stats --no-stream | grep nexus-
```

RAM total debería estar < 18 GB.

---

## SEMANA 2 · Cuando ya tengas 1 cliente activo

Recién entonces deploya:
- Authentik + Infisical (SSO real)
- Ghost (blog CMS)
- Cal.com (booking)
- Crawl4AI + RSSHub
- Postgres exporter + Redis exporter + node-exporter
- Prometheus + Grafana
- Ollama en Oracle Cloud VM2

---

## SEMANA 3+

- Agent Zero (cuando haya caso de uso real)
- Skyvern + Browserless (TikTok)
- Multi-tenant UI completo
- Langfuse (LLM observability)

---

*Honest bootstrap · sin "todo funciona mágicamente" · v1.1*
