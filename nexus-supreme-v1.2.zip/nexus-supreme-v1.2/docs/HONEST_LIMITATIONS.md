# 🚫 HONEST LIMITATIONS · NEXUS v1.1

> Lo que el deploy kit NO hace. Si tu cliente espera estas cosas día 1, no se las prometas.

---

## 🟥 NO HACE AUTOMÁTICAMENTE

### 1. Workspaces multi-tenant en Dify
**Razón técnica:** Dify v0.13 no expone API pública para crear workspaces vía script. Hay que hacerlo en la UI manualmente por cada cliente.

**Workaround:**
- Día 1: 1 workspace global, tags por tenant en metadata
- Semana 2-3: cuando se necesite real, considerar Dify Cloud o esperar feature en versión futura

### 2. Instancias Evolution por cliente
**Razón técnica:** Cada cliente necesita su propio número WhatsApp + escanear QR. **No se puede automatizar** sin acceso al teléfono del cliente.

**Workaround:**
- Onboarding manual: schedule call con cliente, escanear QR juntos
- Tiempo: 15-30 min por cliente

### 3. Multi-tenant en NocoBase a nivel UI
**Razón técnica:** NocoBase tiene roles, pero no workspaces aislados out-of-the-box.

**Workaround:**
- Usar columna `tenant_slug` + row-level security via roles
- Cada cliente ve solo sus filas (filtrado por NocoBase ACL)
- Funcional, pero NO es aislamiento físico

### 4. Listas Listmonk automáticas
**Razón técnica:** La API de Listmonk crea listas, pero el setup completo (template, double opt-in, footer legal) requiere ajuste manual.

**Workaround:**
- Plantilla base por tier (lite/pro/enterprise)
- Auto-creación de 3 listas básicas + edición manual de templates

### 5. Cuentas sociales del cliente en Postiz
**Razón técnica:** OAuth con FB/IG/LinkedIn requiere el cliente autentique desde su navegador. **No se puede hacer por script.**

**Workaround:**
- Onboarding: schedule call → cliente entra a Postiz con SSO → conecta sus cuentas
- Tiempo: 10 min por red social

---

## 🟨 HACE PERO CON CAVEATS

### 6. Ollama local
**Promesa v1.0:** "Inferencia local con Qwen2.5-14B costo cero"
**Realidad:** En CPU de 8 vCPU, Qwen2.5-14B rinde **5-12 tokens/sec**. Inaceptable para producción.

**Solución v1.1:** Ollama se mueve a **Oracle Cloud VM2** (donde James ya tiene 3 VMs ARM). Se llama vía LiteLLM como cualquier otro proveedor.

### 7. Skyvern para TikTok
**Promesa v1.0:** "Automatización de TikTok via browser AI"
**Realidad:** Skyvern necesita:
- OpenAI API key con buen budget ($50+/mes solo en GPT-4 vision)
- TikTok puede detectar y bloquear el navegador automatizado
- No es 100% confiable, falla 10-30% de los uploads

**Solución v1.1:** Skyvern es **semana 3+**, NO core. Para día 1, "social scheduling" = FB + IG + LinkedIn solamente.

### 8. Backups
**Promesa v1.0:** "Backup diario a MinIO"
**Realidad:** MinIO en mismo VPS = NO es backup real (disco failure, ransomware borran ambos).

**Solución v1.1:** restic + Oracle Object Storage (gratis 20 GB) o Backblaze B2 ($6/TB/mes). **Cifrado client-side.**

### 9. Observabilidad
**Promesa v1.0:** "Grafana + Prometheus con dashboards completos"
**Realidad:** Mi `prometheus.yml` v1.0 tenía targets (`postgres_exporter`, `redis_exporter`, `node-exporter`) que NO desplegué.

**Solución v1.1:** Día 3 = Beszel (Docker stats nativo, 1 contenedor, 50 MB) + Uptime Kuma. Grafana + Prometheus + exporters → **semana 2** con todos los exporters reales.

### 10. HITL approval
**Promesa v1.0:** "Aprobación 1 click en Dashy"
**Realidad:** El widget de Dashy hacia un endpoint custom que NO existía. Tenías que construirlo.

**Solución v1.1:** Usar **n8n Forms** (feature nativa desde n8n 1.30) en vez de Dashy custom. Forms da UI lista con botones Aprobar/Rechazar.

---

## 🟩 LO QUE SÍ HACE CONFIABLEMENTE

- 8 servicios día 1 corriendo + accesibles vía HTTPS con TLS
- LiteLLM con 5 modelos cloud + cadena de fallback
- Dify funcional con LiteLLM como provider
- n8n queue mode con worker
- Multi-tenant a **nivel datos**: schemas Postgres + colecciones Qdrant + virtual keys LiteLLM con budget
- Postgres con users por app (security)
- Backup cifrado externo con restic
- Validación de secrets ANTES del deploy
- 3 workflows n8n importables con HITL real (n8n Forms)

---

## ⏱️ TIEMPOS HONESTOS

| Fase | Tiempo de calendario | Trabajo activo |
|---|---|---|
| Día 1 fase 1 | 6-10 horas | 2-3 horas (resto = pull de imágenes) |
| Día 2 fase 2 | 4-6 horas | 2-3 horas (Evolution QR + configs manuales) |
| Día 3 fase 3 | 3-4 horas | 1-2 horas |
| Primer cliente piloto onboarded | +1 día | 2-4 horas |

**Total realista: 4-5 días calendario para tener un cliente facturando.**

NO 72 horas como prometía v1.0. Eso era marketing.

---

## 🎯 PRODUCTO COMERCIAL VENDIBLE DÍA 4

No vendas "agencia 100% automatizada". Vende:

**"AI Lead Auditor + WhatsApp Follow-up + Reporte Semanal"**
- Cliente envía sus leads (formulario web/CRM)
- NEXUS califica con IA + redacta respuesta personalizada en español
- Operador AI Nexus aprueba/edita en 30 segundos
- WhatsApp del cliente envía el mensaje
- Reporte semanal automático por email
- **Precio sugerido:** USD $500-1500/mes/cliente

Cuando este producto valida $$ con 3-5 clientes, **entonces** escala a:
- Content factory (blogs + social + email)
- Automated nurturing
- Multi-channel campaigns

---

*Honesto. Sin promesas que no se cumplen. v1.1*
