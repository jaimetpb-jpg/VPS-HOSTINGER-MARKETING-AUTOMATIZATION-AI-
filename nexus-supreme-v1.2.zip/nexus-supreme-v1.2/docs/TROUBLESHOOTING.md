# 🆘 TROUBLESHOOTING · NEXUS SUPREME

> Problemas comunes y cómo resolverlos rápido.

---

## DIAGNÓSTICO RÁPIDO

Antes que nada, corre:
```bash
bash scripts/03-validate.sh
```

Te dirá qué gate falla. Luego busca abajo.

---

## STACK NO LEVANTA

### Síntoma: `docker compose up` retorna error
1. Verifica que las redes existan:
   ```bash
   docker network ls | grep nexus-
   ```
   Si falta alguna: `bash scripts/00-prepare-vps.sh`

2. Verifica `.env`:
   ```bash
   ls -la .env  # debe tener permisos 600
   grep -c "CAMBIAME" .env  # debe ser 0
   ```

3. Si el problema es puerto ocupado:
   ```bash
   netstat -tlnp | grep -E "80|443"
   # Apagar nginx/apache si estaba corriendo:
   systemctl stop nginx apache2 2>/dev/null
   ```

### Síntoma: `nexus-postgres` no arranca
```bash
docker logs nexus-postgres --tail 100
```
Causa común: volumen `postgres_data` quedó de un deploy anterior con otra password.
**Fix (CUIDADO, borra DBs):**
```bash
cd 02-beta
docker compose --env-file ../.env down -v
docker volume rm $(docker volume ls -q | grep postgres)
docker compose --env-file ../.env up -d
```

### Síntoma: Authentik no arranca por DB
```bash
docker logs nexus-authentik --tail 50
```
Si dice "database does not exist":
- `init-dbs.sql` no se ejecutó (Postgres tenía data previa)
- Crear DB manualmente:
  ```bash
  docker exec nexus-postgres psql -U nexus -c "CREATE DATABASE authentik;"
  docker restart nexus-authentik
  ```

---

## LITELLM / LLM ROUTER

### Síntoma: `curl https://llm.ainexus.mx/v1/chat/completions` retorna 401
- API key incorrecta. Usa `$LITELLM_MASTER_KEY` del `.env`.

### Síntoma: Retorna 500 con "no providers configured"
- Las API keys de proveedores no están en el environment del container.
- Reinicia con env: `docker compose -f 03-gamma/docker-compose.yml --env-file ../.env restart litellm`

### Síntoma: Fallback no se activa
- Verificar `litellm-config.yaml` syntax (no tabs, solo spaces)
- Test manual con modelo que sabes que está caído:
  ```bash
  curl -X POST https://llm.ainexus.mx/v1/chat/completions \
    -H "Authorization: Bearer $LITELLM_MASTER_KEY" \
    -d '{"model":"creative","messages":[{"role":"user","content":"test"}]}'
  ```
- Logs: `docker logs nexus-litellm | grep -i fallback`

### Síntoma: Ollama no responde
```bash
docker exec nexus-ollama ollama list  # ¿están los modelos?
docker exec nexus-ollama ollama pull qwen2.5:14b  # re-pull si falta
docker logs nexus-ollama --tail 30
```
Si el contenedor revienta por OOM:
```bash
free -h  # ¿RAM disponible?
# Bajar el modelo a 7b:
docker exec nexus-ollama ollama pull qwen2.5:7b
# Editar litellm-config.yaml y cambiar model: ollama/qwen2.5:14b → 7b
docker restart nexus-litellm
```

---

## DIFY

### Síntoma: Dify Web carga pero no conecta con API
- Variable `CONSOLE_API_URL` debe coincidir con dominio público
- Verificar Traefik routing:
  ```bash
  curl -sk https://dify.ainexus.mx/console/api/health
  ```

### Síntoma: Workflows fallan con "no model available"
- En Dify UI: Settings → Model Providers → ¿Está LiteLLM configurado?
- Base URL DEBE ser `http://litellm:4000/v1` (interno, no público)
- API key: tu `LITELLM_MASTER_KEY`

### Síntoma: Knowledge Base no embebe
- Verificar Qdrant: `curl http://localhost:6333/collections`
- Logs: `docker logs nexus-dify-worker`

---

## N8N

### Síntoma: Workflow no triggea por webhook
- URL debe ser exactamente: `https://n8n.ainexus.mx/webhook/<path>` (production)
- O `/webhook-test/<path>` (manual test mode)
- Verificar que el workflow esté **Activo** (toggle arriba derecha)

### Síntoma: "Cannot connect to database"
- Variable `DB_POSTGRESDB_HOST` debe ser `postgres` (nombre del container, no IP)
- Verificar que `n8n` DB existe:
  ```bash
  docker exec nexus-postgres psql -U nexus -c "\l" | grep n8n
  ```

### Síntoma: Workers no procesan jobs
```bash
docker logs nexus-n8n-worker-1 --tail 30
```
Causa común: Redis no acepta conexiones porque cambió la password.
Fix: restart workers después de cambiar `REDIS_PASS`.

### Síntoma: Wait node se queda colgado para siempre
- Webhook resume URL debe ser PÚBLICA y accesible
- Test:
  ```bash
  curl -X POST https://n8n.ainexus.mx/webhook-waiting/<execution_id>/<webhook_path>
  ```

---

## EVOLUTION API / WHATSAPP

### Síntoma: QR no aparece o expira
```bash
curl -X DELETE https://wa.ainexus.mx/instance/logout/ainexus-main \
  -H "apikey: $EVOLUTION_API_KEY"
curl -X DELETE https://wa.ainexus.mx/instance/delete/ainexus-main \
  -H "apikey: $EVOLUTION_API_KEY"
curl -X POST https://wa.ainexus.mx/instance/create \
  -H "apikey: $EVOLUTION_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"instanceName":"ainexus-main","qrcode":true}'
```
Abrir UI: `https://wa.ainexus.mx/manager` → escanear QR fresh.

### Síntoma: Mensajes no llegan a n8n
- Verificar webhook global: `WEBHOOK_GLOBAL_URL=https://n8n.ainexus.mx/webhook/wa-inbound`
- En n8n: workflow `whatsapp-concierge` debe estar **Active**
- Test:
  ```bash
  docker logs nexus-evolution | grep -i webhook
  ```

---

## RAM / RECURSOS

### Síntoma: VPS lento o servicios caen aleatoriamente
```bash
free -h
docker stats --no-stream | sort -k 4 -r -h | head
```

**Si Ollama usa >12 GB:** está cargando modelo más grande de lo configurado.
Fix: en `03-gamma/docker-compose.yml`, sección Ollama `deploy.resources.limits.memory: 11G`.

**Si Postgres usa >2 GB:** muchas conexiones abiertas. Verificar:
```bash
docker exec nexus-postgres psql -U nexus -c "SELECT count(*) FROM pg_stat_activity;"
```
Si >100: hay leak en algún servicio. Reiniciar n8n workers suele resolver.

**Solución nuclear si RAM revienta:**
1. Apagar Ollama: `docker compose -f 03-gamma/docker-compose.yml stop ollama`
2. Editar `litellm-config.yaml`: quitar `local-fast` y `local-tiny` del routing
3. `docker restart nexus-litellm`
4. Recuperas 9-11 GB. Migra Ollama a Oracle Cloud VM2.

---

## TLS / SSL

### Síntoma: Browser dice "Certificate not valid"
- DNS aún no propagó. Espera 5-10 min y reintenta.
- Verifica: `dig +short <subdomain>.ainexus.mx` debe retornar IP del VPS
- Traefik solo puede renovar si el dominio resuelve correctamente

### Síntoma: Let's Encrypt rate-limited
- Si reiniciaste muchas veces, hits el limit de LE (5 fallos/hora)
- Espera 1 hora y vuelve a intentar
- Workaround: usar staging temporalmente
  ```yaml
  - "--certificatesresolvers.le.acme.caServer=https://acme-staging-v02.api.letsencrypt.org/directory"
  ```

---

## DISCO LLENO

```bash
df -h
docker system df
```

### Limpieza segura:
```bash
docker image prune -a       # imágenes no usadas
docker volume prune          # CUIDADO, lee la lista antes de aceptar
docker builder prune         # cache de builds
journalctl --vacuum-time=7d  # logs sistema viejos
```

### Si Postgres llena disco:
```bash
docker exec nexus-postgres psql -U nexus -c "VACUUM FULL;"
```

---

## RESET COMPLETO (último recurso)

⚠ **BORRA TODO. Hacer backup primero.**

```bash
bash scripts/05-backup.sh
cd /opt/nexus
for stack in 06-foxtrot 05-echo 04-delta 03-gamma 02-beta 01-alfa; do
  cd "$stack"
  docker compose --env-file ../.env down -v
  cd ..
done
docker volume prune -f
docker network prune -f
bash scripts/00-prepare-vps.sh
bash scripts/02-deploy-all.sh
```

---

## LOGS EN VIVO

- **Web UI:** `https://logs.ainexus.mx` (Dozzle)
- **CLI:** `docker logs -f nexus-<servicio>`
- **All at once:** `docker compose -f <stack>/docker-compose.yml logs -f`

---

## CONTACTOS DE EMERGENCIA

- Hostinger Support: panel.hostinger.com → Chat 24/7
- DNS Cloudflare/proveedor: revisar propagación en https://dnschecker.org
- Logs históricos: en `/opt/nexus/backups/<fecha>/`

---

*Si el problema no está aquí, busca en logs y abre issue interno.*
