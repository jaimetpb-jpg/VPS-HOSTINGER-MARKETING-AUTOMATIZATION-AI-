# 🏗️ ARQUITECTURA · NEXUS SUPREME

> Síntesis del mejor de 6 propuestas LLM. Cada decisión explicada.

---

## DIAGRAMA GLOBAL

```
┌─────────────────────────────────────────────────────────────────────┐
│  INTERNET · Cliente · Redes sociales · WhatsApp                    │
└──────────────────────────────┬─────────────────────────────────────┘
                               │ HTTPS (TLS Let's Encrypt automático)
                ┌──────────────▼──────────────┐
                │   STACK ALFA · SEGURIDAD     │
                │   Traefik + Authentik + Infisical + Vaultwarden     │
                │   Middleware: SSO obligatorio para endpoints internos│
                └──────────────┬──────────────┘
                               │
        ┌──────────────────────┼──────────────────────┐
        │                      │                      │
   ┌────▼──────────┐  ┌────────▼─────────┐  ┌────────▼──────────┐
   │ STACK BETA    │  │ STACK GAMMA      │  │ STACK DELTA       │
   │ DATOS         │  │ CEREBRO AI       │  │ ORQUESTACIÓN+HITL │
   │               │  │                  │  │                   │
   │ Postgres 16   │◄─┤ LiteLLM Router   │◄─┤ n8n main + 2 workers
   │  (14 DBs)     │  │  ├ Local (Ollama)│  │ Dify (hub central) │
   │ Redis (DBs 0-5)  │  ├ DeepSeek API  │  │ Dashy (HITL panel)│
   │ Qdrant (vector)  │  ├ Claude API    │  │ Crawl4AI + RSSHub │
   │ MinIO (object)│  │  ├ GPT API       │  │                   │
   │               │  │  └ Gemini API    │  │                   │
   │ init-dbs.sql  │  │ Ollama (Qwen2.5) │  │                   │
   │ + multi-tenant│  │ Cache Redis 70%+ │  │                   │
   └───────────────┘  └──────────────────┘  └─────────┬─────────┘
                                                       │
                ┌──────────────────────────────────────┴──────────┐
                │                                                  │
       ┌────────▼──────────────────────────┐  ┌──────────────────▼─────┐
       │ STACK ECHO · ARSENAL MARKETING    │  │ STACK FOXTROT          │
       │                                    │  │ OBSERVABILIDAD         │
       │ Postiz (FB/IG/X/LinkedIn)          │  │                        │
       │ Evolution API (WhatsApp multi-inst)│  │ Grafana + Prometheus   │
       │ Ghost (blog)                       │  │ Uptime Kuma            │
       │ Listmonk (email mass)              │  │ Beszel (sys stats)     │
       │ NocoBase (CRM)                     │  │ Dozzle (logs live)     │
       │ Cal.com (booking)                  │  │                        │
       │ Matomo (analytics privado)         │  │                        │
       │ Skyvern + Browserless (TikTok)     │  │                        │
       └────────────────────────────────────┘  └────────────────────────┘
```

---

## 5 REDES DOCKER AISLADAS (de Kimi)

| Red | Tráfico | Servicios |
|---|---|---|
| `nexus-public` | Internet ↔ servicios públicos vía Traefik | Traefik + UIs públicas |
| `nexus-backbone` | **Internal-only** · DB-bound traffic | Postgres + Redis + workers DB |
| `nexus-ai` | AI workloads | Ollama, LiteLLM, Dify, Qdrant |
| `nexus-automation` | n8n + integraciones outbound | n8n, workers, Postiz, Ghost, etc. |
| `nexus-monitoring` | Métricas | Prometheus, Grafana, Beszel |

**Por qué importa:** un servicio comprometido en `nexus-public` no puede tocar la DB directamente — debe pasar por su microservicio en `nexus-automation` que sí tiene grant a `nexus-backbone`.

---

## DECISIONES DE INGENIERÍA

### 1. Postgres compartido (de Claude/yo)
**Decisión:** UNA instancia de Postgres con 14 DBs vs ~10 Postgres separados.
**Por qué:** ahorra **~8 GB de RAM** (cada Postgres usa ~800 MB base).
**Trade-off:** acoplamiento. Si Postgres cae, todo cae. Mitigado por backup diario + monitoring.

### 2. Dify como hub central (de Claude/yo)
**Decisión:** Dify reemplaza Flowise + Langflow + MaxKB + Open Notebook.
**Por qué:** una UI, un set de credenciales, un patrón mental. Menos superficie de mantenimiento.
**Trade-off:** dependencia en una herramienta. Si Dify pivotea, hay que migrar.

### 3. LiteLLM como router universal (de Kimi + GPT + DeepSeek)
**Decisión:** TODO LLM call pasa por LiteLLM. Nunca llamar APIs directamente.
**Por qué:**
- Cache Redis: 70% de queries son repetidas → ahorro masivo
- Fallback automático: si Claude cae, GPT entra solo
- Budget per virtual key: control de costos por tenant
- Métricas unificadas: 1 dashboard para todo

### 4. Cadena de fallback explícita (de Kimi)
```
creative → strategy → cheap-spanish
cheap-spanish → local-fast → creative
strategy → creative → long-research
```
Sin esto, downtime de Anthropic = downtime de tu fábrica. Con esto, tu fábrica sobrevive caídas de cualquier proveedor.

### 5. Multi-tenant día 1 (de Kimi)
**3 capas de aislamiento por cliente:**
- Schema Postgres `tenant_<slug>` (datos)
- Colección Qdrant `tenant_<slug>_knowledge` (vectores RAG)
- Grupo Authentik `tenant-<slug>` (acceso UI)
- Virtual Key LiteLLM con budget por tier (LLM cost control)

**Por qué importa:** AI Nexus vende como agencia. Sin esto, mezclas datos de clientes y violas confianza (y posiblemente LFPDPPP).

### 6. HITL como ciudadano de primera (de DeepSeek)
**Patrón en TODOS los workflows críticos:**
```
Generación AI → ai_task.status = 'awaiting_approval'
              → notify operator (WhatsApp + Dashy)
              → n8n Wait node pausa el flujo
              → humano click Aprobar/Rechazar
              → webhook resume + branch
```
**Por qué:** una agencia que cobra por publicar contenido **NO** puede publicar sin que el humano lo apruebe. Punto.

### 7. Modo Tutor (de DeepSeek)
Cuando el humano rechaza + da feedback:
- Se guarda en tabla `tutor_corrections`
- Se embeddea en Qdrant
- Próximo workflow del mismo tipo recupera la corrección como contexto

Resultado: el sistema **aprende del operador humano** sin fine-tuning explícito.

### 8. Sanitizer pattern (de Gemini)
Todo input de scraper → función JS que:
- Quita saltos de línea
- Colapsa whitespace
- Limita a 8000 chars
- Retorna JSON estructurado

**Por qué:** Ollama con input >10k tokens en VPS de 32GB = OOM. Esto previene crashes.

### 9. Skyvern para TikTok (de DeepSeek)
TikTok no tiene API pública para posting. Skyvern controla un navegador headless con LLM que "ve" la UI y publica. Resuelve un problema que ningún scheduler tradicional resuelve.

### 10. Reparto Hostinger ↔ Oracle (de Claude/yo)
- **Hostinger KVM 8 (32 GB):** todo el stack productivo
- **Oracle Cloud 3 VMs ARM (ya existentes):** backup mirror, Ollama escalado si RAM revienta, CrewAI experimental

**No duplicar trabajo.** Si Oracle ya tiene Qdrant primario, Hostinger usa Qdrant como cache local + sync. Si la RAM se llena, Ollama migra a Oracle VM2.

### 11. GO/NO-GO Gates (de GPT)
3 gates obligatorios. No avanzas sin pasar el anterior.
- Gate 1 (h14): infraestructura UP + LiteLLM responde
- Gate 2 (h30): workflow HITL ejecuta end-to-end
- Gate 3 (h72): tenant nuevo onboarding <3h

**Por qué:** previene el patrón clásico de "tengo todo desplegado pero nada funciona". Cada gate fuerza validación end-to-end.

---

## ASIGNACIÓN DE RAM (32 GB total)

| Stack | Servicios | RAM |
|---|---|---|
| Alfa | Traefik + Authentik (server+worker+db) + Infisical + Vaultwarden | 2.5 GB |
| Beta | Postgres + Redis + Qdrant + MinIO | 2.5 GB |
| Gamma | LiteLLM + Ollama (Qwen2.5-14B 11GB cap) + Dify (api+worker+web+sandbox) | 13 GB |
| Delta | n8n + 2 workers + Dashy + RabbitMQ + Crawl4AI + RSSHub | 3 GB |
| Echo | Postiz + Ghost + Listmonk + Matomo + Cal + NocoBase + Evolution + Skyvern + Browserless | 9 GB |
| Foxtrot | Grafana + Prometheus + Beszel + Uptime Kuma + Dozzle | 1.5 GB |
| **TOTAL** | | **31.5 GB** |

Headroom 0.5 GB + swap 4 GB.

**Plan de contingencia:** si revientas, apaga Ollama (-9 GB) y usa solo LLMs cloud vía LiteLLM. Recuperas 9 GB.

---

## STACKS Y QUIÉN APORTÓ QUÉ

| Stack | Idea base | Refinamientos |
|---|---|---|
| Alfa (seguridad) | Kimi | Authentik forward-auth de Kimi + Infisical para secrets |
| Beta (datos) | Claude | init-dbs.sql shared (Claude) + 5 networks aisladas (Kimi) |
| Gamma (AI) | Kimi (LiteLLM) + Claude (Dify) | Cadena fallback (Kimi+GPT) + DeepSeek API (DeepSeek) |
| Delta (orquestación) | Claude (n8n queue mode) | Dashy HITL panel (DeepSeek) + sanitizer (Gemini) |
| Echo (marketing) | Claude + DeepSeek | Skyvern + Browserless (DeepSeek) + Evolution multi-inst (LATAM) |
| Foxtrot (observabilidad) | Kimi | Beszel por sus dashboards específicos para Docker stats |

---

*Documento vivo · Actualizar cuando cambien decisiones estructurales*
