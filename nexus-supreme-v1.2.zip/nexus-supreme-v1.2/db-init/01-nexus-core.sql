-- ═══════════════════════════════════════════════════════════════
-- NEXUS v1.2 · 01-nexus-core.sql
-- Tablas operativas en nexus_core (tenants, ai_task, tutor_corrections, leads)
-- BUG #9 fix: tabla `leads` simple aquí, evita NocoBase como CRM día 2
-- ═══════════════════════════════════════════════════════════════

-- Este archivo se ejecuta dentro de la DB nexus_core
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── TENANTS ───
CREATE TABLE IF NOT EXISTS tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    contact_email VARCHAR(200),
    contact_whatsapp VARCHAR(50),
    tier VARCHAR(20) DEFAULT 'lite',
    status VARCHAR(20) DEFAULT 'active',
    onboarded_at TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug);
CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants(status);

-- ─── AI TASKS ───
CREATE TABLE IF NOT EXISTS ai_task (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    workflow_name VARCHAR(100) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    input_payload JSONB,
    output_payload JSONB,
    model_used VARCHAR(50),
    tokens_in INT DEFAULT 0,
    tokens_out INT DEFAULT 0,
    cost_usd NUMERIC(10,4) DEFAULT 0,
    approver_user VARCHAR(100),
    approval_notes TEXT,
    n8n_form_url TEXT,           -- NUEVO v1.2: URL del n8n Form de aprobación
    created_at TIMESTAMPTZ DEFAULT NOW(),
    approved_at TIMESTAMPTZ,
    published_at TIMESTAMPTZ,
    error_message TEXT
);

CREATE INDEX IF NOT EXISTS idx_ai_task_tenant ON ai_task(tenant_id);
CREATE INDEX IF NOT EXISTS idx_ai_task_status ON ai_task(status);
CREATE INDEX IF NOT EXISTS idx_ai_task_created ON ai_task(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_task_workflow ON ai_task(workflow_name);

-- ─── TUTOR CORRECTIONS (Modo Tutor) ───
CREATE TABLE IF NOT EXISTS tutor_corrections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    workflow_name VARCHAR(100) NOT NULL,
    original_output TEXT NOT NULL,
    corrected_output TEXT NOT NULL,
    correction_reason TEXT,
    qdrant_point_id VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tutor_tenant ON tutor_corrections(tenant_id);

-- ─── LEADS (BUG #9 fix: reemplaza NocoBase día 2) ───
-- Tabla simple gestionable directamente desde n8n con nodos Postgres
CREATE TABLE IF NOT EXISTS leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(200),
    email VARCHAR(200),
    phone VARCHAR(50),
    company VARCHAR(200),
    website VARCHAR(300),
    message TEXT,
    source VARCHAR(100),
    utm_source VARCHAR(100),
    utm_campaign VARCHAR(100),
    score INT DEFAULT 0,
    tier VARCHAR(20) DEFAULT 'COLD',   -- HOT|WARM|COLD
    intent TEXT,
    qualified_at TIMESTAMPTZ,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_leads_tenant ON leads(tenant_id);
CREATE INDEX IF NOT EXISTS idx_leads_tier ON leads(tier);
CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX IF NOT EXISTS idx_leads_created ON leads(created_at DESC);

-- Trigger para updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_leads_updated_at ON leads;
CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ─── VIEW KPIs ───
CREATE OR REPLACE VIEW v_tenant_kpis AS
SELECT
    t.id AS tenant_id,
    t.slug,
    t.name,
    t.tier,
    COUNT(DISTINCT a.id) FILTER (WHERE a.created_at > NOW() - INTERVAL '30 days') AS tasks_30d,
    COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'published' AND a.created_at > NOW() - INTERVAL '30 days') AS published_30d,
    COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'rejected' AND a.created_at > NOW() - INTERVAL '30 days') AS rejected_30d,
    COUNT(DISTINCT l.id) FILTER (WHERE l.created_at > NOW() - INTERVAL '30 days') AS leads_30d,
    COUNT(DISTINCT l.id) FILTER (WHERE l.tier = 'HOT' AND l.created_at > NOW() - INTERVAL '30 days') AS hot_leads_30d,
    SUM(a.cost_usd) FILTER (WHERE a.created_at > NOW() - INTERVAL '30 days') AS llm_cost_30d
FROM tenants t
LEFT JOIN ai_task a ON a.tenant_id = t.id
LEFT JOIN leads l ON l.tenant_id = t.id
WHERE t.status = 'active'
GROUP BY t.id, t.slug, t.name, t.tier;

-- ─── SEED: AI Nexus como primer tenant ───
INSERT INTO tenants (slug, name, contact_email, tier)
VALUES ('ainexus', 'AI Nexus (interno)', 'james@ainexus.com.mx', 'enterprise')
ON CONFLICT (slug) DO NOTHING;
