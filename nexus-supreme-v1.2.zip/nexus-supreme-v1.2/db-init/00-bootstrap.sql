-- ═══════════════════════════════════════════════════════════════
-- NEXUS v1.2 · 00-bootstrap.sql · Idempotente
--
-- FIX BUG #1 (Kimi): /docker-entrypoint-initdb.d/ solo corre con
-- volumen vacío. Esto SE EJECUTA SIEMPRE vía script bash que
-- llama psql con este archivo. Cada CREATE protegido con IF NOT EXISTS
-- vía bloques DO $$ ... $$.
--
-- Passwords vienen como variables psql con \set (más seguro que sed)
-- ═══════════════════════════════════════════════════════════════

-- ─────── USERS POR APP ───────
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'dify_app') THEN
        EXECUTE format('CREATE ROLE dify_app LOGIN PASSWORD %L', :'pg_dify_pass');
    ELSE
        EXECUTE format('ALTER ROLE dify_app WITH PASSWORD %L', :'pg_dify_pass');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'n8n_app') THEN
        EXECUTE format('CREATE ROLE n8n_app LOGIN PASSWORD %L', :'pg_n8n_pass');
    ELSE
        EXECUTE format('ALTER ROLE n8n_app WITH PASSWORD %L', :'pg_n8n_pass');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'litellm_app') THEN
        EXECUTE format('CREATE ROLE litellm_app LOGIN PASSWORD %L', :'pg_litellm_pass');
    ELSE
        EXECUTE format('ALTER ROLE litellm_app WITH PASSWORD %L', :'pg_litellm_pass');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'nexus_core_app') THEN
        EXECUTE format('CREATE ROLE nexus_core_app LOGIN PASSWORD %L', :'pg_nexus_core_pass');
    ELSE
        EXECUTE format('ALTER ROLE nexus_core_app WITH PASSWORD %L', :'pg_nexus_core_pass');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'nocobase_app') THEN
        EXECUTE format('CREATE ROLE nocobase_app LOGIN PASSWORD %L', :'pg_nocobase_pass');
    ELSE
        EXECUTE format('ALTER ROLE nocobase_app WITH PASSWORD %L', :'pg_nocobase_pass');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'listmonk_app') THEN
        EXECUTE format('CREATE ROLE listmonk_app LOGIN PASSWORD %L', :'pg_listmonk_pass');
    ELSE
        EXECUTE format('ALTER ROLE listmonk_app WITH PASSWORD %L', :'pg_listmonk_pass');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'postiz_app') THEN
        EXECUTE format('CREATE ROLE postiz_app LOGIN PASSWORD %L', :'pg_postiz_pass');
    ELSE
        EXECUTE format('ALTER ROLE postiz_app WITH PASSWORD %L', :'pg_postiz_pass');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'evolution_app') THEN
        EXECUTE format('CREATE ROLE evolution_app LOGIN PASSWORD %L', :'pg_evolution_pass');
    ELSE
        EXECUTE format('ALTER ROLE evolution_app WITH PASSWORD %L', :'pg_evolution_pass');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'plausible_app') THEN
        EXECUTE format('CREATE ROLE plausible_app LOGIN PASSWORD %L', :'pg_plausible_pass');
    ELSE
        EXECUTE format('ALTER ROLE plausible_app WITH PASSWORD %L', :'pg_plausible_pass');
    END IF;
END $$;

-- ─────── DBs (con SELECT pg_database.datname → idempotente) ───────
-- Postgres NO permite CREATE DATABASE dentro de DO $$, hay que verificar antes
SELECT 'CREATE DATABASE dify OWNER dify_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'dify')\gexec

SELECT 'CREATE DATABASE n8n OWNER n8n_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'n8n')\gexec

SELECT 'CREATE DATABASE litellm OWNER litellm_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'litellm')\gexec

SELECT 'CREATE DATABASE nexus_core OWNER nexus_core_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'nexus_core')\gexec

SELECT 'CREATE DATABASE nocobase OWNER nocobase_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'nocobase')\gexec

SELECT 'CREATE DATABASE listmonk OWNER listmonk_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'listmonk')\gexec

SELECT 'CREATE DATABASE postiz OWNER postiz_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'postiz')\gexec

SELECT 'CREATE DATABASE evolution OWNER evolution_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'evolution')\gexec

SELECT 'CREATE DATABASE plausible_db OWNER plausible_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'plausible_db')\gexec

-- ─────── GRANTS ───────
GRANT ALL PRIVILEGES ON DATABASE dify TO dify_app;
GRANT ALL PRIVILEGES ON DATABASE n8n TO n8n_app;
GRANT ALL PRIVILEGES ON DATABASE litellm TO litellm_app;
GRANT ALL PRIVILEGES ON DATABASE nexus_core TO nexus_core_app;
GRANT ALL PRIVILEGES ON DATABASE nocobase TO nocobase_app;
GRANT ALL PRIVILEGES ON DATABASE listmonk TO listmonk_app;
GRANT ALL PRIVILEGES ON DATABASE postiz TO postiz_app;
GRANT ALL PRIVILEGES ON DATABASE evolution TO evolution_app;
GRANT ALL PRIVILEGES ON DATABASE plausible_db TO plausible_app;

REVOKE ALL ON DATABASE dify FROM PUBLIC;
REVOKE ALL ON DATABASE n8n FROM PUBLIC;
REVOKE ALL ON DATABASE litellm FROM PUBLIC;
REVOKE ALL ON DATABASE nexus_core FROM PUBLIC;
